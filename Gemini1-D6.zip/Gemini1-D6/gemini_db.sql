Drop database if exists gemini_db;

CREATE DATABASE if not exists gemini_db ;

use gemini_db;

CREATE TABLE if not exists users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

INSERT INTO users (username, password) VALUES ('adm1n', 'adm1n');

