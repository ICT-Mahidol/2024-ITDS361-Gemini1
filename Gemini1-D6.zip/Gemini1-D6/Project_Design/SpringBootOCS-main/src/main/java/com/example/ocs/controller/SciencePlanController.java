package com.example.ocs.controller;

import com.example.ocs.dto.SciencePlanDTO;
import edu.gemini.app.ocs.OCS;
import edu.gemini.app.ocs.example.MySciencePlan;
import edu.gemini.app.ocs.model.DataProcRequirement;
import edu.gemini.app.ocs.model.SciencePlan;
import edu.gemini.app.ocs.model.StarSystem;
import org.springframework.web.bind.annotation.*;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

@RestController
@RequestMapping("/api/science-plan")
public class SciencePlanController {

    private static final OCS ocs = new OCS(true);
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    @PostMapping("/create")
    public String createSciencePlan(@RequestBody SciencePlanDTO dto) {
        System.out.println(dto);

        MySciencePlan mySP = new MySciencePlan();
        mySP.setCreator(dto.creator);
        mySP.setSubmitter(dto.submitter);
        mySP.setFundingInUSD(dto.fundingInUSD);
        mySP.setObjectives(dto.objectives);
        mySP.setStarSystem(StarSystem.CONSTELLATIONS.valueOf(dto.starSystem));

        // แปลง LocalDateTime -> String
        mySP.setStartDate(dto.startDate.format(formatter));
        mySP.setEndDate(dto.endDate.format(formatter));

        mySP.setTelescopeLocation(SciencePlan.TELESCOPELOC.valueOf(dto.telescopeLocation));

        DataProcRequirement dpr1 = new DataProcRequirement("JPEG", "Low", "Color mode",
                11, 10, 5, 0, 7, 0,
                0, 0, 10, 8);
        mySP.setDataProcRequirements(dpr1);

        ocs.createSciencePlan(mySP);
        return "Science plan created successfully!";
    }

    @GetMapping("/all")
    public ArrayList<SciencePlan> getAllSciencePlans() {
        return ocs.getAllSciencePlans(); // หรือวิธีดึงจากระบบของคุณ
    }

    @PostMapping("/submit/{planNo}")
    public String submitPlan(@PathVariable int planNo) {
        ocs.updateSciencePlanStatus(planNo, SciencePlan.STATUS.COMPLETE);
        System.out.println(ocs.getSciencePlanByNo(planNo));
        return "Plan " + planNo + " submitted successfully.";
    }

    @PostMapping("/test/{id}")
    public String testPlan(@PathVariable int id) {
        return ocs.testSciencePlan(ocs.getSciencePlanByNo(id));
    }
}
