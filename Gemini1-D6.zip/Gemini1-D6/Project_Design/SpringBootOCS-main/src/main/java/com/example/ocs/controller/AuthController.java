package com.example.ocs.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AuthController {

    @GetMapping("/login")
    public String loginPage() {
        return "login"; // หน้า login
    }

    @GetMapping("/welcome")
    public String welcome() {
        return "welcome"; // หน้า welcome
    }

    @GetMapping("/dashboard")
    public String dashboard() {
        return "dashboard"; // หน้า dashboard
    }

    @GetMapping("/createplan")
    public String createplan() {
        return "createplan"; // หน้า create science plan
    }

    @GetMapping("/submitplan")
    public String submitplan() {
        return "submitplan"; // หน้า submit science plan
    }

    @GetMapping("/testplan")
    public String testplan() {
        return "testplan"; // หน้า test science plan
    }
}
