package com.example.ocs.dto;

import java.time.LocalDateTime;

public class SciencePlanDTO {
    public String creator;
    public String submitter;
    public Double fundingInUSD;
    public String objectives;
    public String starSystem;
    public LocalDateTime startDate;
    public LocalDateTime endDate;
    public String telescopeLocation;
}