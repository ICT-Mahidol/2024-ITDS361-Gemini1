package com.example.Gemini1.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        // ใช้ NoOpPasswordEncoder สำหรับกรณีที่ไม่ต้องการการเข้ารหัส
        return NoOpPasswordEncoder.getInstance();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/login", "/css/**").permitAll()  // เปิดให้เข้าถึงหน้า login และ css
                        .requestMatchers("/welcome").authenticated()  // ต้องล็อกอินก่อนถึงจะเข้าหน้า welcome ได้
                        .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .loginPage("/login")  // หน้า login ที่เราสร้างเอง
                        .defaultSuccessUrl("/welcome", true)  // เมื่อเข้าสู่ระบบสำเร็จ ให้ไปที่หน้า /welcome
                        .permitAll()  // อนุญาตให้ทุกคนเข้าถึงหน้า login
                )
                .logout(logout -> logout.logoutSuccessUrl("/login").permitAll());  // หน้า logout

        return http.build();
    }
}
